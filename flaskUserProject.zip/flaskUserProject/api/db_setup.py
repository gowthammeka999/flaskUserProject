import psycopg2


def get_db_connection():
    conn = psycopg2.connect(host='localhost',
                            database='focus',
                            user='postgres',
                            password='XXXXX')
    return conn