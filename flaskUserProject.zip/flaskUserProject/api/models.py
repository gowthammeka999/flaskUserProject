from marshmallow import Schema, fields


class UserRoleSchema(Schema):
    user = fields.Str(default='test')
    role = fields.Str(default='engineer')