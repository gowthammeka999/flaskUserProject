import json

from flask import request, jsonify
from flask_apispec import marshal_with
from flask_apispec.views import MethodResource
from flask_restful import Resource

from api.db_setup import get_db_connection
from api.models import UserRoleSchema


class UserDetail(MethodResource, Resource):
    @marshal_with(UserRoleSchema)
    def get(self, user=None):
        """
        Get method represents a GET API method
        """
        qry = 'SELECT * FROM Users where '
        if user is not None:
            qry += "user='%s';" % user
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute(qry)
            details = cur.fetchall()
            cur.close()
            conn.close()
            return jsonify({'response': details})
        return jsonify({'Error': 'Bad request: User not provided'}), 404


class AddUser(MethodResource, Resource):
    @marshal_with(UserRoleSchema)
    def post(self):
        user, role = None, None
        try:
            body = json.loads(request.body)
            if body and (None not in [body.get('user'), body.get('role')]):
                user, role = body.get('user'), body.get('role')
        except Exception as e:
            return jsonify({'Error': 'Invalid request'}), 404

        if user and role:
            qry = 'INSERT INTO User VALUES(%s, %s)' % (user, role)
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute(qry)
            cur.close()
            conn.close()
            return jsonify({'response': 'updated'}), 202

