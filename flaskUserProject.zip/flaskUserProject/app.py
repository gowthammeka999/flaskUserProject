from flask import Flask
from flask_restful import Api

from api.views import UserDetail, AddUser

app = Flask(__name__)


api = Api(app)

api.add_resource(AddUser, '/user', endpoint='add_user')
api.add_resource(UserDetail, '/user/<string:user>', endpoint='get_user')



if __name__ == '__main__':
    app.run()
